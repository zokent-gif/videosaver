package com.example.videosaver

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Volatile var ytUpdated = false

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val shared = intent?.getStringExtra(android.content.Intent.EXTRA_TEXT).orEmpty()
        setContent {
            val dark = isSystemInDarkTheme()
            val ctx = LocalContext.current
            val scheme = if (Build.VERSION.SDK_INT >= 31)
                (if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx))
            else (if (dark) darkColorScheme() else lightColorScheme())
            MaterialTheme(colorScheme = scheme) { Screen(shared) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Screen(initialUrl: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var url by remember { mutableStateOf(initialUrl) }
    var progress by remember { mutableFloatStateOf(0f) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Вставьте ссылку на видео") }
    val snack = remember { SnackbarHostState() }

    fun start() {
        if (url.isBlank() || busy) return
        busy = true; progress = 0f; status = "Подготовка…"
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    if (!ytUpdated) {
                        status = "Обновление загрузчика…"
                        runCatching { YoutubeDL.getInstance().updateYoutubeDL(ctx.applicationContext) }
                        ytUpdated = true
                        status = "Подготовка…"
                    }
                    val dir = File(ctx.cacheDir, "dl").apply { deleteRecursively(); mkdirs() }
                    val req = YoutubeDLRequest(url.trim()).apply {
                        addOption("-o", "${dir.absolutePath}/%(title).80s.%(ext)s")
                        addOption("-f", "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/b")
                        addOption("--merge-output-format", "mp4")
                        addOption("--no-playlist")
                    }
                    YoutubeDL.getInstance().execute(req, "dl") { p, _, line ->
                        progress = (p / 100f).coerceIn(0f, 1f)
                        status = if (p < 100f) "Загрузка… ${p.toInt()}%" else "Обработка…"
                    }
                    val file = dir.listFiles()?.firstOrNull() ?: error("Файл не найден")
                    saveToGallery(ctx, file)
                    file.name
                }
            }
            busy = false
            result.onSuccess { status = "Готово: сохранено в галерею"; progress = 1f; snack.showSnackbar("Сохранено: $it") }
                .onFailure { status = "Ошибка"; snack.showSnackbar(it.message?.take(300) ?: "Не удалось скачать", duration = SnackbarDuration.Long) }
        }
    }

    Scaffold(
        topBar = { LargeTopAppBar(title = { Text("Video Saver") }) },
        snackbarHost = { SnackbarHost(snack) }
    ) { pad ->
        Column(
            Modifier.padding(pad).padding(horizontal = 20.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = url, onValueChange = { url = it },
                label = { Text("Ссылка на видео") },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                trailingIcon = {
                    IconButton(onClick = { clipboard.getText()?.text?.let { url = it } }) {
                        Icon(Icons.Filled.ContentPaste, "Вставить")
                    }
                }
            )
            Button(onClick = ::start, enabled = !busy && url.isNotBlank(), modifier = Modifier.fillMaxWidth().height(56.dp)) {
                Icon(Icons.Filled.Download, null); Spacer(Modifier.width(8.dp)); Text("Скачать")
            }
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(status, style = MaterialTheme.typography.titleMedium)
                    if (busy) LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                }
            }
            Text(
                "Скачивайте только то, на что у вас есть права. Работает с YouTube и сотнями других сайтов.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

fun saveToGallery(ctx: Context, file: File) {
    val values = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        if (Build.VERSION.SDK_INT >= 29) {
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/VideoSaver")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
    }
    val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: error("MediaStore error")
    ctx.contentResolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
    if (Build.VERSION.SDK_INT >= 29) {
        ctx.contentResolver.update(uri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
    }
    file.delete()
}
