package com.example.videosaver

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Fmt(val label: String, val ext: String, val audio: Boolean)
data class Info(val title: String, val thumb: String?, val dur: Long)
data class Item(val title: String, val thumb: String?, val fmt: String, val time: Long)

val FORMATS = listOf(
    Fmt("MP4", "mp4", false), Fmt("WEBM", "webm", false), Fmt("MKV", "mkv", false),
    Fmt("MP3", "mp3", true), Fmt("M4A", "m4a", true)
)

object History {
    private fun sp(c: Context) = c.getSharedPreferences("hist", Context.MODE_PRIVATE)
    fun load(c: Context): List<Item> = runCatching {
        val a = JSONArray(sp(c).getString("l", "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Item(o.getString("t"), o.optString("p").ifBlank { null }, o.getString("f"), o.getLong("d"))
        }
    }.getOrDefault(emptyList())

    fun save(c: Context, l: List<Item>) {
        val a = JSONArray()
        l.forEach { h -> a.put(JSONObject().put("t", h.title).put("p", h.thumb ?: "").put("f", h.fmt).put("d", h.time)) }
        sp(c).edit().putString("l", a.toString()).apply()
    }
}

@Volatile private var ytUpdated = false

@Synchronized
fun ensureUpdated(ctx: Context) {
    if (ytUpdated) return
    runCatching { YoutubeDL.getInstance().updateYoutubeDL(ctx.applicationContext) }
    ytUpdated = true
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val shared = intent?.getStringExtra(android.content.Intent.EXTRA_TEXT).orEmpty()
        setContent {
            val dark = isSystemInDarkTheme()
            val ctx = LocalContext.current
            val scheme = if (Build.VERSION.SDK_INT >= 31)
                (if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx))
            else (if (dark) darkColorScheme() else lightColorScheme())
            MaterialTheme(colorScheme = scheme) { Screen(shared) }
        }
    }
}

fun fmtDur(s: Long): String {
    val h = s / 3600; val m = s % 3600 / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Screen(initialUrl: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var url by remember { mutableStateOf(initialUrl) }
    var info by remember { mutableStateOf<Info?>(null) }
    var fmt by remember { mutableStateOf(FORMATS[0]) }
    var progress by remember { mutableFloatStateOf(0f) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Вставьте ссылку на видео") }
    var history by remember { mutableStateOf(History.load(ctx)) }
    val snack = remember { SnackbarHostState() }
    val dateFmt = remember { SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()) }

    LaunchedEffect(url) {
        info = null
        val u = url.trim()
        if (!u.startsWith("http")) return@LaunchedEffect
        delay(700)
        info = withContext(Dispatchers.IO) {
            runCatching {
                ensureUpdated(ctx)
                val req = YoutubeDLRequest(u).apply {
                    addOption("--no-playlist")
                    addOption("--extractor-args", "youtube:player_client=android_vr")
                }
                val i = YoutubeDL.getInstance().getInfo(req)
                Info(i.title ?: "", i.thumbnail, i.duration.toString().toLongOrNull() ?: 0L)
            }.getOrNull()
        }
    }

    fun start() {
        if (url.isBlank() || busy) return
        val f = fmt; val cur = info; val link = url.trim()
        busy = true; progress = 0f; status = "Подготовка…"
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    ensureUpdated(ctx)
                    val dir = File(ctx.cacheDir, "dl").apply { deleteRecursively(); mkdirs() }
                    val req = YoutubeDLRequest(link).apply {
                        addOption("-o", "${dir.absolutePath}/%(title).80s.%(ext)s")
                        addOption("--no-playlist")
                        addOption("-N", "8")
                        addOption("--extractor-args", "youtube:player_client=android_vr")
                        when (f.ext) {
                            "mp4" -> { addOption("-f", "b[ext=mp4]/bv*[ext=mp4]+ba[ext=m4a]/b"); addOption("--merge-output-format", "mp4") }
                            "webm" -> { addOption("-f", "bv*[ext=webm]+ba[ext=webm]/b[ext=webm]/b"); addOption("--merge-output-format", "webm") }
                            "mkv" -> { addOption("-f", "bv*+ba/b"); addOption("--merge-output-format", "mkv") }
                            else -> { addOption("-f", "ba/b"); addOption("-x"); addOption("--audio-format", f.ext) }
                        }
                    }
                    YoutubeDL.getInstance().execute(req, "dl") { p, _, _ ->
                        progress = (p / 100f).coerceIn(0f, 1f)
                        status = if (p < 100f) "Загрузка… ${p.toInt()}%" else "Обработка…"
                    }
                    val file = dir.listFiles()?.firstOrNull() ?: error("Файл не найден")
                    saveToMedia(ctx, file, f)
                    file.nameWithoutExtension
                }
            }
            busy = false
            result.onSuccess { name ->
                status = "Готово: сохранено в галерею"; progress = 1f
                val title = cur?.title?.ifBlank { null } ?: name
                history = (listOf(Item(title, cur?.thumb, f.label, System.currentTimeMillis())) + history).take(100)
                History.save(ctx, history)
                snack.showSnackbar("Сохранено: $title")
            }.onFailure { e ->
                status = "Ошибка"
                val msg = e.message.orEmpty()
                val err = msg.lines().lastOrNull { l -> l.startsWith("ERROR") } ?: msg.takeLast(300)
                snack.showSnackbar(err.take(300).ifBlank { "Не удалось скачать" }, duration = SnackbarDuration.Long)
            }
        }
    }

    Scaffold(
        topBar = {
            LargeTopAppBar(title = { Text("Video Saver") }, actions = {
                if (history.isNotEmpty()) IconButton(onClick = { history = emptyList(); History.save(ctx, history) }) {
                    Icon(Icons.Filled.Delete, "Очистить историю")
                }
            })
        },
        snackbarHost = { SnackbarHost(snack) }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).padding(horizontal = 20.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                OutlinedTextField(
                    value = url, onValueChange = { url = it },
                    label = { Text("Ссылка на видео") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    trailingIcon = {
                        IconButton(onClick = { clipboard.getText()?.text?.let { url = it } }) {
                            Icon(Icons.Filled.ContentPaste, "Вставить")
                        }
                    }
                )
            }
            info?.let { i ->
                item {
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column {
                            Box {
                                AsyncImage(
                                    model = i.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                                )
                                if (i.dur > 0) Surface(
                                    color = Color.Black.copy(alpha = 0.7f), shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp)
                                ) {
                                    Text(fmtDur(i.dur), color = Color.White, style = MaterialTheme.typography.labelMedium,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                            }
                            Text(i.title, Modifier.padding(16.dp), style = MaterialTheme.typography.titleMedium, maxLines = 2)
                        }
                    }
                }
            }
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FORMATS.forEach { x -> FilterChip(selected = fmt == x, onClick = { fmt = x }, label = { Text(x.label) }) }
                }
            }
            item {
                Button(onClick = ::start, enabled = !busy && url.isNotBlank(), modifier = Modifier.fillMaxWidth().height(56.dp)) {
                    Icon(Icons.Filled.Download, null); Spacer(Modifier.width(8.dp)); Text("Скачать")
                }
            }
            item {
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(status, style = MaterialTheme.typography.titleMedium)
                        if (busy) LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            if (history.isNotEmpty()) item { Text("История загрузок", style = MaterialTheme.typography.titleLarge) }
            items(history) { h ->
                ListItem(
                    leadingContent = {
                        AsyncImage(model = h.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                            modifier = Modifier.size(64.dp, 40.dp).clip(RoundedCornerShape(8.dp)))
                    },
                    headlineContent = { Text(h.title, maxLines = 2) },
                    supportingContent = { Text("${h.fmt} · ${dateFmt.format(Date(h.time))}") }
                )
            }
            item {
                Text(
                    "Скачивайте только то, на что у вас есть права.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

fun saveToMedia(ctx: Context, file: File, f: Fmt) {
    val mime = when (f.ext) {
        "mp4" -> "video/mp4"; "webm" -> "video/webm"; "mkv" -> "video/x-matroska"
        "mp3" -> "audio/mpeg"; else -> "audio/mp4"
    }
    val collection = if (f.audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
        put(MediaStore.MediaColumns.MIME_TYPE, mime)
        if (Build.VERSION.SDK_INT >= 29) {
            put(MediaStore.MediaColumns.RELATIVE_PATH, (if (f.audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES) + "/VideoSaver")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
    }
    val uri = ctx.contentResolver.insert(collection, values) ?: error("MediaStore error")
    ctx.contentResolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
    if (Build.VERSION.SDK_INT >= 29) {
        ctx.contentResolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
    }
    file.delete()
}
